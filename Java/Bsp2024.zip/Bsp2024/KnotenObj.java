class KnotenObj {
  public KnotenObj naechstes;
  public Object element;
  
  public KnotenObj(Object meinElement)  {
    naechstes = null;
    element = meinElement;
  }
   
}
