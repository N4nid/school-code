/**
 *
 * Beschreibung
 *
 * @version 1.0 vom 11.11.2024
 * @author 
 */

public class BinaerBaum { // bitte kommentieren
  
  // Anfang Attribute
  private BinaerKnoten wurzel;
  // Ende Attribute
  
  // Anfang Methoden
  public BinaerKnoten getWurzel() {
    return wurzel;
  }
  
  public BinaerBaum(int myKey){
    wurzel = new BinaerKnoten(1,myKey);
  }
    

  public void setWurzel(BinaerKnoten wurzelNeu) {
    wurzel = wurzelNeu;
  }

  public void einfuegen(int key) {
    // TODO hier Quelltext einfügen
    wurzel.einfuegen(1,key);
  }

  public BinaerKnoten search(int key) {
    // TODO hier Quelltext einfügen
    return null;
  }

  public void delete(int key) {
    // TODO hier Quelltext einfügen
    
  }

  public void ausgabeInorder(StapelObj stack) {
    // TODO hier Quelltext einfügen
    wurzel.ausgabeInorder(stack); 
  }

  // Ende Methoden
} // end of binaerbaum
